package com.example.todo;

import com.example.todo.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Scanner;

@SpringBootApplication
public class TodoApplication implements CommandLineRunner {

    @Autowired
    private TaskService taskService;

    @Autowired
    private Scanner scanner;

    public static void main(String[] args) {
        SpringApplication.run(TodoApplication.class, args);
    }

    @Override
    public void run(String... args) {
        while (true) {
            System.out.println("\n1. Add Task\n2. View Tasks\n3. Remove Task\n4. Exit");
            System.out.print("Choose: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // flush

            switch (choice) {
                case 1:
                    System.out.print("Enter task: ");
                    String desc = scanner.nextLine();
                    taskService.add(desc);
                    break;
                case 2:
                    int i = 0;
                    for (var task : taskService.list()) {
                        System.out.println((i++) + ": " + task.getDescription());
                    }
                    break;
                case 3:
                    System.out.print("Enter task index to remove: ");
                    int idx = scanner.nextInt();
                    taskService.remove(idx);
                    break;
                case 4:
                    System.exit(0);
                default:
                    System.out.println("Invalid option.");
            }
        }
    }
}