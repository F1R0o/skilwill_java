package com.example.todo.service;

import com.example.todo.component.TaskStorage;
import com.example.todo.model.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskService {

    private final TaskStorage storage;

    @Autowired
    public TaskService(TaskStorage storage) {
        this.storage = storage;
    }

    public void add(String desc) {
        storage.addTask(new Task(desc));
    }

    public List<Task> list() {
        return storage.getAll();
    }

    public void remove(int index) {
        storage.removeTask(index);
    }
}